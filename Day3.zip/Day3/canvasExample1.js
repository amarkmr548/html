var canvas1=document.getElementById("canvas1");
var context1=canvas1.getContext("2d")
context1.moveTo(50,50);
context1.lineTo(100,100);
context1.strokeStyle="blue";
context1.lineCap="square"
context1.lineWidth=10;

context1.stroke();
/* context1.moveTo(100,100);
context1.lineTo(150,150);
context1.strokeStyle="#09f";
context1.lineCap="round"
context1.lineWidth=5;

context1.stroke();
context1.moveTo(150,150);
context1.lineTo(200,200);
context1.strokeStyle="rgba(255,255,0,.5)";
context1.lineCap="square";
context1.lineWidth=10;

context1.stroke();
 */
var canvas2=document.getElementById("canvas2");
var context2=canvas2.getContext("2d");
context2.fillStyle="pink";
context2.fillRect(25,25, 100,200);

var canvas3=document.getElementById("canvas3");
var context3=canvas3.getContext("2d");
context3.fillStyle="rgb(255,0,0)";
context3.fillRect(10,10,50,50);
context3.fillStyle="rgb(255,255,0)";
context3.fillRect(30,30,50,50);

var canvas4=document.getElementById("canvas4");
var context4=canvas4.getContext("2d");
var lineJoin=['round','bevel','miter'];
context4.lineWidth=10;
context4.strokeStyle="blue";
for(var i=0;i<lineJoin.length;i++)
{
    context4.lineJoin=lineJoin[i];
    context4.beginPath();
    context4.moveTo(-5,5+i*40);
    context4.lineTo(35,45+i*40);
    context4.lineTo(75,5+i*40);
    context4.lineTo(115,45+i*40);
    context4.stroke();
    
}

var canvas5=document.getElementById("canvas5");
var context5=canvas5.getContext("2d");
var lGradient=context5.createLinearGradient(0,0,canvas5.width/2,canvas5.height/2);
lGradient.addColorStop(0,"yellow");
lGradient.addColorStop(.7,"red");
lGradient.addColorStop(1.0,"black");
context5.fillStyle=lGradient;
context5.fillRect(50,50,100,150);

var canvas6=document.getElementById("canvas6");
var context6=canvas6.getContext("2d");
var img=new Image();
img.src="tile2.gif";
img.onload=function onLoadEventHandler()
{
    var pattern=context6.createPattern(img,"no-repeat");
    context6.fillStyle=pattern;
    context6.fillRect(25,25,1000,1200);
}



