var canvas1=document.getElementById("canvas1");
var context1=canvas1.getContext("2d")
context1.beginPath();
context1.moveTo(75,50);
context1.lineTo(100,75);
context1.lineTo(100,25);
context1.fill();
//context1.stroke();

var canvas2=document.getElementById("canvas2");
var context2=canvas2.getContext("2d")
context2.beginPath();
context2.strokeStyle="pink";
context2.fillStyle="cyan";

context2.arc(50,50,30,0,2* Math.PI,false)
//context2.arc(150,150,60,0,2* Math.PI,true)
context2.fill();
context2.stroke();

var canvas3=document.getElementById("canvas3");
var context3=canvas3.getContext("2d")
context3.font="36px Calibri";
//context3.strokeText("HTML",50,50);
context3.textBaseLine="bottom";
context3.textAlign="end";
context3.direction="ltr"
context3.fillText("HTML",150,150)