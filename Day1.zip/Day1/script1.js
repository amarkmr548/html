function clickImageEventHandler()
{
    alert("Thank u for clicking on my image");
    var imgElement1=document.getElementById("imgFlower1");
    imgElement1.src="waterfall.jpeg";
    var imgElement2=document.getElementById("citiLogoImg");

    imgElement2.style.border="15px solid red";
    

}