function clickEventHandler()
{
    var userNameElement=document.getElementById("txtUserName");
    userNameElement.style.border="5px solid yellow";
}

function inputEventHandler(event)
{
    //var userNameElement=document.getElementById("txtUserName");
    //console.log("Input Event triggered with "+userNameElement.value);
    console.log("Input Event triggered with "+event.target.value);
    console.log("Input element",event);
    var elemnt=document.getElementById(event.target.id);
    elemnt.style.fontSize="36px";
}

function changeEventHandler(event)
{
    //var userNameElement=document.getElementById("txtUserName");
    //console.log("Change Event triggered with "+userNameElement.value);
    console.log("Change Event triggered with "+event.target.value);
}

function blurEventHandler()
{
    var userNameElement=document.getElementById("txtUserName");
    userNameElement.style.border="1px solid black"
}

function resetEventHandler(event)
{
    console.log("Inside reset");
    var userNameElement=document.getElementById("txtUserName");
    userNameElement.value="";
    console.log("Event details",event);
    event.preventDefault();
}

function myEventHandler(p1)
{
    var eleemnt=document.getElementById(p1);
    console.log("Value = "+eleemnt.value);

}

function loginEventHandler()
{
    var form1=document.getElementById("form1");
    console.log("form1",form1);
    var checkboxMale=document.getElementById("checkboxMale");
    if(checkboxMale.checked)
    {
        console.log("Male");
    }
    var checkboxFemale=document.getElementById("checkboxFemale");
    if(checkboxFemale.checked)
    {
        console.log("Female");
    }
    var checkboxOthers=document.getElementById("checkboxOthers");
    if(checkboxOthers.checked)
    {
        console.log("Others");
    }
    var ddlEducation=document.getElementById("ddlEducation");
    console.log("Education Index :"+ddlEducation.selectedIndex);
    console.log("SElected value for education"+ddlEducation.options[ddlEducation.selectedIndex].textContent);
}

function popCountriesEventHandler()
{
    var myCountries=document.getElementById("ddlCountries");
    var countryNames=["India","USA","Australia","England"];
    myCountries.innerHTML="";
    for(let i=0;i<countryNames.length;i++)
    {
        var optionElement=document.createElement("option");
        optionElement.innerHTML=countryNames[i];
        myCountries.appendChild(optionElement);
    }
}

function submitEventHandler(event)
{
    var userName=document.getElementById("txtUserName").value;
    var password=document.getElementById("txtPassword").value;// "" whenever the textbox is empty 
    if(userName =="anju" && password=="anju")
    {
        return true;
    }
    else
    {
        event.preventDefault();
        var errorMessage=document.getElementById("errorMessage");
        errorMessage.innerHTML="Username/Password is incorrect";
        return false;
    }
    
}